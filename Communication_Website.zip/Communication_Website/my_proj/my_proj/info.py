EMAIL_USE_TLS=True
EMAIL_HOST='smtp.gmail.com'
EMAIL_HOST_USER='buddy12system@gmail.com'
EMAIL_HOST_PASSWORD='Ashutosh@123456'
EMAIL_PORT=587
